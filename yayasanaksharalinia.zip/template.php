<?php include 'layout/header.php'; ?>
</head>

<body>
    <?php include 'layout/navbar.php' ?>



    <!--Footer -->
    <?php include 'layout/footer.php'; ?>